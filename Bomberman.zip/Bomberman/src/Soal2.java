
public class Soal2 {

}
